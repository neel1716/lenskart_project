package mouseHoverLenskart;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.compGlassMouseHoverRepo_lenskart;
import repository.compGlassMouseHoverRepo_lenskart;

import org.testng.annotations.BeforeTest;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class Mousehover
{
	WebDriver driver;



	@BeforeTest
	public void beforeTest() throws Exception 
	{
		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.lenskart.com/");
		Thread.sleep(2000);


	}
	@Test
	public void computerGlassesMouseHover() throws Exception 
	{
		

		//Creating object of Action class

		Actions a  = new Actions(driver);
		

		Thread.sleep(50000);

		for(int i=1;i<=3;i++)
		{
			a.moveToElement(compGlassMouseHoverRepo_lenskart.computerGlassesMouseHover(driver)).build().perform();
			Thread.sleep(2000);
			for(int j=1;j<=2;j++)
			{
				a.moveToElement(compGlassMouseHoverRepo_lenskart.computerGlassesMouseHover(driver)).build().perform();
				Thread.sleep(2000);
				a.moveToElement(compGlassMouseHoverRepo_lenskart.mainLink(driver,i)).build().perform();
				Thread.sleep(2000);
				a.moveToElement(compGlassMouseHoverRepo_lenskart.subLink(driver, i, j)).build().perform();
				Thread.sleep(2000);
				compGlassMouseHoverRepo_lenskart.subLink(driver, i, j).click();
				Thread.sleep(3000);
				driver.navigate().back();
				Thread.sleep(3000);
				System.out.println(i+ " , " +j);
			}
			
		}
		
		 
		
		 
	}


	@AfterTest
	public void afterTest() 
	{

	}

}
