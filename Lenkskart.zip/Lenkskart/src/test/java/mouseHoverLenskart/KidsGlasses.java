package mouseHoverLenskart;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.KidsGlassesRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class KidsGlasses 
{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() throws Exception
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.lenskart.com/");
		Thread.sleep(2000);
		
		
	 }
  @Test
  public void kidsGlasses() throws Exception 
  {
	  Actions a = new Actions(driver);
	
	Thread.sleep(2000);
	for(int i = 1; i<=3 ; i++)
	{
		a.moveToElement(KidsGlassesRepo.kidsGlasses(driver)).build().perform();
		Thread.sleep(2000);
		KidsGlassesRepo.eyeGlasses(driver, i).click();
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(2000);
		System.out.println(i);
	}
  }
  

  @AfterTest
  public void afterTest()
  {
  }

}
