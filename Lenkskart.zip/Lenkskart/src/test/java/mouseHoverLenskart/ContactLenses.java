package mouseHoverLenskart;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.ContactLensesRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class ContactLenses
{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() throws Exception 
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.lenskart.com/");
		Thread.sleep(2000);
		
		
	  }
  @Test
  public void contactLenses() throws Exception
  
 {
	  Actions a = new Actions(driver);
	  a.moveToElement(ContactLensesRepo.contactLenses(driver)).build().perform();
	  Thread.sleep(2000);
	  for(int i =1 ; i<=5 ; i++)
	  {
		  int size = ContactLensesRepo.subLinkBrands(driver, i).size();
		  System.out.println("No. of sublinks for main link at position "+i+ " are :"+size);
		  for(int j=0 ; j<size ; j++)
		  {
			  
		a.moveToElement(ContactLensesRepo.subLinkBrands(driver, i).get(j)).build().perform();
		System.out.println(ContactLensesRepo.subLinkBrands(driver, i).get(j).getText());
	    Thread.sleep(2000);
	  }
	  }
  }
  

  @AfterTest
  public void afterTest() 
  {
}

}
