package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginRepo 
{
	static WebElement element;
	public static void url(WebDriver driver)
	{
		driver.get("https://www.lenskart.com/");
	}
	public static WebElement clickonSignIn(WebDriver driver)
	{
		 element= driver.findElement(By.xpath("//*[@id=\"topNavigationBar\"]/div[1]/div[3]/div/div[2]/div/div/div/span[1]"));
		 return element;
	}
	public static WebElement mobileNumber(WebDriver driver)
	{
		element = driver.findElement(By.name("emailOrPhone"));
		return  element;
	}
	
	public static WebElement proceedButton(WebDriver driver)
	{
		element = driver.findElement(By.name("send"));
		return element;
	}
	public static WebElement afterOtpProceed(WebDriver driver)
	{
		element = driver.findElement(By.name("send"));
		return element;
	}
	public static WebElement welcomeAdmin(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\"topNavigationBar\"]/div[1]/div[3]/div/div[2]/div/div/div/div[1]"));
		return element;
		
	}
	public static WebElement logout(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Logout"));
		return element;
	}
	public static WebElement clickonCross(WebDriver driver)
	{
		element = driver.findElement(By.linkText("X"));
		return element;
	}

}
