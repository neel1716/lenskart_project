package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationRepo 
{
	static WebElement element;
	public static void url(WebDriver driver)
	{
	driver.get("https://www.lenskart.com/");
	
	}
	public  static WebElement clickonSignup(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//span[contains(text(),'Sign Up')]"));
		return element;
	}
	public static WebElement firstName(WebDriver driver)
	{
		element = driver.findElement(By.name("firstName"));
		return element;
	}
	public static WebElement lastName(WebDriver driver)
	{
		element=driver.findElement(By.name("lastName"));
		return element;
	}
	public static WebElement mobileNumber(WebDriver driver)
	{
		element= driver.findElement(By.name("mobile"));
		return element;
	}
	public static WebElement emailAddress(WebDriver driver)
	{
		element= driver.findElement(By.name("email"));
		return element;
	}
	public static WebElement password(WebDriver driver)
	{
		element= driver.findElement(By.name("password"));
		return element;
	}
	public static WebElement clickOnRegister(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//*[@id=\"content\"]/div/header/div[2]/div/div[1]/div[2]/div/div/div/div/div[2]/div[2]/form/div[7]/button"));
		return element;
	}
	public static WebElement ClickonCross(WebDriver driver)
	{
		element = driver.findElement(By.linkText("X"));
		return element;
	}

}
