package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchProductRepo
{
	static WebElement element;
	
	
	public static void url(WebDriver driver)
	{
		driver.get("https://www.lenskart.com/");
	}
	
	public static WebElement trendingSearch(WebDriver driver)
	{
		element = driver.findElement(By.name("q"));
		return element;
	}
	public static List resultValidfound(WebDriver driver)
	{
		
		List<WebElement> results = driver.findElements(By.className("img-responsive"));
		return results;
	}
	public static WebElement noResultFound(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//p[contains(text(),'No results found!!!')]"));
		return element;
		
	}

}
