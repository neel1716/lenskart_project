package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class compGlassMouseHoverRepo_lenskart
{
	static WebElement element;
	
	
	public static WebElement computerGlassesMouseHover(WebDriver driver)
	{
		element = driver.findElement(By.linkText("COMPUTER GLASSES"));
		return element;
	}
	public static WebElement mainLink(WebDriver driver,int i)
	{
		element = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[2]/nav[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["  +i+ "]/div[1]/span[1]"));
		return element;
	}
	public static WebElement subLink(WebDriver driver,int i,int j)
	{
		element=driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[2]/nav[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[" +i+ "]/div[2]/div[1]/div[" +j+ "]/a[1]/div[1]/div[1]/span[2]"));
		return element;
	}

}
