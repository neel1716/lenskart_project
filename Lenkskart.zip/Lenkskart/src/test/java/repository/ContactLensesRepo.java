package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ContactLensesRepo 
{
	static WebElement element;
	public static WebElement contactLenses(WebDriver driver)
	{
		element = driver.findElement(By.linkText("CONTACT LENSES"));
		return element;
	}
	public static WebElement contactLensMainLinks(WebDriver driver, int j)
	{
		element = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[2]/nav[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[" +j+ "]/div[1]/div"));
		return element;
	}
	
	 public static List <WebElement> subLinkBrands(WebDriver driver,int i)
	 { 
		List <WebElement> submenus = driver.findElements(By.xpath("//header[1]/div[2]/div[1]/div[1]/div[2]/nav[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div["  +i+  "]/div[1]/div"));
		return submenus;
	 
	
	}
	

}
