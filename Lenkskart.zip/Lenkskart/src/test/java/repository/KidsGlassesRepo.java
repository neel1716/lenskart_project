package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class KidsGlassesRepo 
{
	static WebElement element;
	public static WebElement kidsGlasses(WebDriver driver)
	{
		element = driver.findElement(By.linkText("KIDS GLASSES"));
		return element;
	}
	public static WebElement eyeGlasses(WebDriver driver,int i)
	{
		element = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[2]/div[1]/div[1]/div[2]/nav[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[" +i+ "]/a[1]/div[1]"));
		return element;
	}

}
