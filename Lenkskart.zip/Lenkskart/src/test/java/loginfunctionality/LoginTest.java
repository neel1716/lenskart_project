package loginfunctionality;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.LoginRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class LoginTest 
{
	WebDriver driver;
	
	@BeforeTest
	  public void beforeTest() throws Exception 
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		LoginRepo.url(driver);
		Thread.sleep(2000);
	    driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		
	  
	}
  @Test
  public void login() throws Exception
  {
	  FileInputStream file=new FileInputStream("Data/lenskart_project_poi_7375.xlsx");
	  XSSFWorkbook w = new XSSFWorkbook(file);
	  XSSFSheet s = w.getSheet("loginData");
	  int rowSize=s.getLastRowNum();
	  System.out.println("No of Data: "+rowSize);
	  
	  LoginRepo.clickonSignIn(driver).click();
	  Thread.sleep(2000);
	  
	  for(int i=2; i<rowSize; i++)
	  {
		  String mobileNumber = s.getRow(i).getCell(0).getStringCellValue();
		 // System.out.println(mobileNumber);
		  
		  
		  LoginRepo.mobileNumber(driver).sendKeys(mobileNumber);
		  Thread.sleep(4000);
		 // System.out.println(LoginRepo.mobileNumber(driver).getAttribute("value"));
		  
		  LoginRepo.proceedButton(driver).click();
		  
		  		  
		  try
		  {
			  Thread.sleep(2000);
			  LoginRepo.afterOtpProceed(driver).click();
			  
			  LoginRepo.welcomeAdmin(driver).click();
			  Thread.sleep(2000);
			  LoginRepo.logout(driver).click();
		  }
		  catch(Exception e)
		  {
			  System.out.println("invalid mobile number:" +mobileNumber);
			 // LoginRepo.clickonCross(driver).click();
			  LoginRepo.mobileNumber(driver).sendKeys(Keys.CONTROL + "a");
			  Thread.sleep(2000);
			  LoginRepo.mobileNumber(driver).sendKeys(Keys.DELETE);
			  Thread.sleep(2000);
			  
		  }
		  
		  
		 
		  
		  
		  
	  }
	  
  }
  

  @AfterTest
  public void afterTest() 
  {
	  //driver.close();
  }

}
