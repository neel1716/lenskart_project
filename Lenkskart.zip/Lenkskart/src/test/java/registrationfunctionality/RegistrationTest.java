package registrationfunctionality;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegistrationRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class RegistrationTest
{
	WebDriver driver;
	
	@BeforeTest
	  public void beforeTest() throws Exception
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
		RegistrationRepo.url(driver);
		Thread.sleep(2000);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		
		
		
	 }
  @Test
  public void registation() throws Exception 
  { 
	  FileInputStream file=new FileInputStream("Data/lenskart_project_poi_7375.xlsx");
	  XSSFWorkbook w = new XSSFWorkbook(file);
	  XSSFSheet s = w.getSheet("RegistrationData");
	  
	  int rowSize=s.getLastRowNum();
	  System.out.println("No of Data: "+rowSize);
	  
	  //for loop to handle excel data
	  
	  
	  for(int i=2; i<rowSize; i++)
	  {
	  String fn = s.getRow(i).getCell(0).getStringCellValue();
	  String ln = s.getRow(i).getCell(1).getStringCellValue();
	  String mbn = s.getRow(i).getCell(2).getStringCellValue();
	  String email = s.getRow(i).getCell(3).getStringCellValue();
	  String pwd  = s.getRow(i).getCell(4).getStringCellValue();
	  System.out.println(fn+" "+ln+" "+mbn+" "+email+" "+pwd);
	  
	  
	  RegistrationRepo.clickonSignup(driver).click();
	  Thread.sleep(2000);
	    RegistrationRepo.firstName(driver).sendKeys(fn);
	  Thread.sleep(2000);
	  RegistrationRepo.lastName(driver).sendKeys(ln);
	  Thread.sleep(2000);
	  RegistrationRepo.mobileNumber(driver).sendKeys(mbn);
	  Thread.sleep(2000);
	  RegistrationRepo.emailAddress(driver).sendKeys(email);
	  Thread.sleep(2000);
	  RegistrationRepo.password(driver).sendKeys(pwd);
	  Thread.sleep(2000);
	  RegistrationRepo.clickOnRegister(driver).click();
	  Thread.sleep(2000);
		/*
		 * //for clearing: RegistrationRepo.firstName(driver).clear();
		 * Thread.sleep(2000); RegistrationRepo.lastName(driver).clear();
		 * RegistrationRepo.mobileNumber(driver).clear();
		 * RegistrationRepo.emailAddress(driver).clear();
		 * RegistrationRepo.password(driver).clear();
		 */
	  
	  RegistrationRepo.ClickonCross(driver).click();
	  
	  }
  }
  

  @AfterTest
  public void afterTest() 
  {
	  
	  driver.close();
  }

}
