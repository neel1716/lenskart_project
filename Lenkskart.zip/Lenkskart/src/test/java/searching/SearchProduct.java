package searching;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.SearchProductRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SearchProduct 
{
	WebDriver driver;
	
	
	@BeforeTest
	  public void beforeTest()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		SearchProductRepo.url(driver);
		
	}
  @Test
  public void searchingProduct() throws Exception 
  {
	  FileInputStream file = new FileInputStream("Data/lenskart_project_poi_7375.xlsx");
	  XSSFWorkbook w = new XSSFWorkbook(file);
	  XSSFSheet s = w.getSheet("SearchingProduct");
	  int rowSize = s.getLastRowNum();
	  System.out.println("Number of data"+rowSize);
	  
	  for(int i =1 ; i<rowSize; i++)
	  {
		  String pn = s.getRow(i).getCell(0).getStringCellValue();
		  System.out.println("Product name" +pn);
		  
		  SearchProductRepo.trendingSearch(driver).sendKeys(pn);
		  Thread.sleep(2000);
 
		  SearchProductRepo.trendingSearch(driver).sendKeys(Keys.ENTER);
		  Thread.sleep(2000);
		  if(SearchProductRepo.resultValidfound(driver).size()>0)
		  {
			 Thread.sleep(2000);
		  System.out.println("Number of results for "+pn+" : "+ SearchProductRepo.resultValidfound(driver).size());
			  
		  }
		  else
		  {
			  Thread.sleep(3000);
			  System.out.println(SearchProductRepo.noResultFound(driver).getText());
		  }
		  
		  
		  SearchProductRepo.trendingSearch(driver).sendKeys(Keys.CONTROL + "a");
		  Thread.sleep(2000);
		  SearchProductRepo.trendingSearch(driver).sendKeys(Keys.DELETE);
	  }
  
  }

  @AfterTest
  public void afterTest() 
  {
	 // driver.close();
  }

}
